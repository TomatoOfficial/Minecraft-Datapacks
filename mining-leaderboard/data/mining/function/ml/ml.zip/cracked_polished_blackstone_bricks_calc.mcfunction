execute as @s run scoreboard players add @s ml.total 1
execute as @s run scoreboard players remove @s ml.cracked_polished_blackstone_bricks 1