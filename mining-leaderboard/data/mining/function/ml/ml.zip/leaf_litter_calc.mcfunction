execute as @s run scoreboard players add @s ml.total 1
execute as @s run scoreboard players remove @s ml.leaf_litter 1