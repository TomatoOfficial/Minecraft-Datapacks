execute as @s run scoreboard players add @s ml.total 1
execute as @s run scoreboard players remove @s ml.infested_cracked_stone_bricks 1