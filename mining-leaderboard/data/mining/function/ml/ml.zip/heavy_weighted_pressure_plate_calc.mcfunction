execute as @s run scoreboard players add @s ml.total 1
execute as @s run scoreboard players remove @s ml.heavy_weighted_pressure_plate 1